// Edit products here. Prices are in INR. Replace image paths with your real photos.
window.PRODUCTS = [
  {
    "id": 1,
    "name": "Rawleaf Madhumeh Nasak Capsule",
    "shortName": "Madhumeh Nasak",
    "price": 450,
    "category": "Blood sugar",
    "description": "Daily blood sugar support",
    "image": "images/product-1.webp",
    "alt": "Rawleaf Madhumeh Nasak Capsule product packaging, 30 capsules",
    "pack": "30 capsules",
    "ingredients": "Complete ingredient information will be added from the product label.",
    "directions": "Follow the product label and your healthcare professional’s advice.",
    "gallery": [
      {
        "src": "images/product-1.webp",
        "alt": "Rawleaf Madhumeh Nasak Capsule product packaging, 30 capsules",
        "label": "Product"
      }
    ]
  },
  {
    "id": 2,
    "name": "Rawleaf Sleepdip Capsule",
    "shortName": "Sleepdip",
    "price": 342,
    "category": "Sleep",
    "description": "Support for your nightly wind-down",
    "image": "images/product-2.webp",
    "alt": "Rawleaf Sleepdip Capsule product packaging, 30 capsules",
    "pack": "30 capsules",
    "ingredients": "Complete ingredient information will be added from the product label.",
    "directions": "Follow the product label and your healthcare professional’s advice.",
    "gallery": [
      {
        "src": "images/product-2.webp",
        "alt": "Rawleaf Sleepdip Capsule product packaging, 30 capsules",
        "label": "Product"
      }
    ]
  },
  {
    "id": 3,
    "name": "Rawleaf Prakritik Shodhak Capsule",
    "shortName": "Prakritik Shodhak",
    "price": 432,
    "category": "Immunity",
    "description": "Everyday immunity support",
    "image": "images/product-3.webp",
    "alt": "Rawleaf Prakritik Shodhak Capsule product packaging, 30 capsules",
    "pack": "30 capsules",
    "ingredients": "Complete ingredient information will be added from the product label.",
    "directions": "Follow the product label and your healthcare professional’s advice.",
    "gallery": [
      {
        "src": "images/product-3.webp",
        "alt": "Rawleaf Prakritik Shodhak Capsule product packaging, 30 capsules",
        "label": "Product"
      }
    ]
  },
  {
    "id": 4,
    "name": "Rawleaf Beta Revive Capsule",
    "shortName": "Beta Revive",
    "price": 615,
    "category": "Metabolism",
    "description": "Support for metabolic wellbeing",
    "image": "images/product-4.webp",
    "alt": "Rawleaf Beta Revive Capsule product packaging, 30 capsules",
    "pack": "30 capsules",
    "ingredients": "Complete ingredient information will be added from the product label.",
    "directions": "Follow the product label and your healthcare professional’s advice.",
    "gallery": [
      {
        "src": "images/product-4.webp",
        "alt": "Rawleaf Beta Revive Capsule product packaging, 30 capsules",
        "label": "Product"
      },
      {
        "src": "images/beta-revive-2.webp",
        "alt": "Rawleaf Beta Revive benefits information supplied by Rawleaf",
        "label": "Benefits"
      },
      {
        "src": "images/beta-revive-3.webp",
        "alt": "Rawleaf Beta Revive ingredients information supplied by Rawleaf",
        "label": "Ingredients"
      },
      {
        "src": "images/beta-revive-4.webp",
        "alt": "Rawleaf Beta Revive metabolism support information supplied by Rawleaf",
        "label": "Metabolism support"
      }
    ]
  },
  {
    "id": 5,
    "name": "Rawleaf Vajan Mukti Capsule",
    "shortName": "Vajan Mukti",
    "price": 570,
    "category": "Weight",
    "description": "Support for weight management",
    "image": "images/product-5.webp",
    "alt": "Rawleaf Vajan Mukti Capsule product packaging, 30 capsules",
    "pack": "30 capsules",
    "ingredients": "Complete ingredient information will be added from the product label.",
    "directions": "Follow the product label and your healthcare professional’s advice.",
    "gallery": [
      {
        "src": "images/product-5.webp",
        "alt": "Rawleaf Vajan Mukti Capsule product packaging, 30 capsules",
        "label": "Product"
      }
    ]
  },
  {
    "id": 6,
    "name": "Rawleaf Vaat Nashak Capsule",
    "shortName": "Vaat Nashak",
    "price": 465,
    "category": "Joints",
    "description": "Support for joint wellbeing",
    "image": "images/product-6.webp",
    "alt": "Rawleaf Vaat Nashak Capsule product packaging, 30 capsules",
    "pack": "30 capsules",
    "ingredients": "Complete ingredient information will be added from the product label.",
    "directions": "Follow the product label and your healthcare professional’s advice.",
    "gallery": [
      {
        "src": "images/product-6.webp",
        "alt": "Rawleaf Vaat Nashak Capsule product packaging, 30 capsules",
        "label": "Product"
      }
    ]
  },
  {
    "id": 7,
    "name": "Rawleaf Menostat Capsule",
    "shortName": "Menostat",
    "price": 330,
    "category": "Menstrual",
    "description": "Menstrual support for women",
    "image": "images/product-7.webp",
    "alt": "Rawleaf Menostat Capsule product packaging, 30 capsules",
    "pack": "30 capsules",
    "ingredients": "Complete ingredient information will be added from the product label.",
    "directions": "Follow the product label and your healthcare professional’s advice.",
    "gallery": [
      {
        "src": "images/product-7.webp",
        "alt": "Rawleaf Menostat Capsule product packaging, 30 capsules",
        "label": "Product"
      }
    ]
  }
];

// Add only approved real offers, for example: { code: "YOURCODE", percent: 5 }.
window.DISCOUNTS = [];
window.REVIEWS = [];
window.BUNDLES = [];
window.OFFER_TEXT = "";
