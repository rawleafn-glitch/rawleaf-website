/* Rawleaf static store. No imports, fetch calls or server required. */
(() => {
  'use strict';
  const products = window.PRODUCTS;
  const KEY = 'rawleaf-cart-v1';
  const UPI = '7003185197-2@okbizaxis';
  const WHATSAPP = '919038152100';
  const money = amount => '₹' + amount.toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const escape = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const find = id => products.find(product => product.id === Number(id));
  let memoryCart = [];
  let discount = null;
  // Ignore corrupt or obsolete saved data instead of breaking the page.
  function readCart() {
    try {
      const raw = JSON.parse(localStorage.getItem(KEY) || '[]');
      if (!Array.isArray(raw)) return [];
      const merged = new Map();
      raw.forEach(item => {
        if (item && find(item.id) && Number.isInteger(item.qty) && item.qty > 0)
          merged.set(Number(item.id), Math.min(99, (merged.get(Number(item.id)) || 0) + item.qty));
      });
      return Array.from(merged, ([id, qty]) => ({id, qty}));
    } catch { return memoryCart; }
  }
  let cart = readCart();
  function save() {
    memoryCart = cart;
    try { localStorage.setItem(KEY, JSON.stringify(cart)); }
    catch { notify('Your browser cannot save this bag. Keep this page open while ordering.'); }
    updateCount();
  }
  function updateCount() { document.getElementById('cart-count').textContent = cart.reduce((n, item) => n + item.qty, 0); }
  let toastTimer;
  function notify(message) {
    const toast = document.getElementById('toast'); toast.textContent = message; toast.classList.add('visible');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('visible'), 3500);
  }
  function add(id, qty = 1) {
    if (!find(id)) return;
    const existing = cart.find(item => item.id === Number(id));
    if (existing) existing.qty = Math.min(99, existing.qty + qty);
    else cart.push({id: Number(id), qty: Math.min(99, qty)});
    save(); notify('Added to your bag.');
  }
  function card(product) {
    return `<article class="product-card"><a class="image-link" href="product.html?id=${product.id}"><img src="${product.image}" alt="${escape(product.alt)}" width="800" height="800" loading="lazy"></a><p class="category">${escape(product.category)} support</p><h3><a href="product.html?id=${product.id}">${escape(product.shortName)}</a></h3><p class="pack">Capsule · ${product.pack}</p><p class="price">${money(product.price)}</p><button class="button outline" data-add="${product.id}" aria-label="Add ${escape(product.name)} to bag">Add to bag</button></article>`;
  }
  document.addEventListener('click', event => {
    const addButton = event.target.closest('[data-add]');
    if (addButton) add(addButton.dataset.add);
  });
  const menu = document.querySelector('.menu-toggle');
  menu.addEventListener('click', () => {
    const open = menu.getAttribute('aria-expanded') !== 'true';
    menu.setAttribute('aria-expanded', String(open)); menu.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    document.getElementById('navigation').classList.toggle('open', open);
  });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') { menu.setAttribute('aria-expanded', 'false'); document.getElementById('navigation').classList.remove('open'); } });
  const page = document.body.dataset.page;
  document.querySelectorAll('nav a').forEach(a => { if (a.getAttribute('href') === page + '.html') a.setAttribute('aria-current','page'); });
  document.getElementById('year').textContent = new Date().getFullYear(); updateCount();
  if (window.OFFER_TEXT) document.getElementById('announcement').textContent = window.OFFER_TEXT;
  const categories = [...new Set(products.map(p => p.category))];
  if (page === 'index') {
    document.getElementById('featured').innerHTML = [1,2,4,6].map(id => card(find(id))).join('');
    document.getElementById('concerns').innerHTML = categories.map(category => `<a href="concern.html?category=${encodeURIComponent(category)}">${escape(category)}</a>`).join('');
    if (window.REVIEWS.length) document.getElementById('reviews').innerHTML = window.REVIEWS.map(r => `<blockquote><p>${escape(r.text)}</p><cite>${escape(r.name)}</cite></blockquote>`).join('');
  }
  if (page === 'shop') {
    const category = document.getElementById('category');
    category.innerHTML += categories.map(c => `<option value="${escape(c)}">${escape(c)}</option>`).join('');
    const requested = new URLSearchParams(location.search).get('category'); if (categories.includes(requested)) category.value = requested;
    function renderShop() {
      const search = document.getElementById('search').value.toLowerCase().trim();
      const sort = document.getElementById('sort').value;
      const filtered = products.filter(p => (category.value === 'all' || p.category === category.value) && (p.name+' '+p.category).toLowerCase().includes(search));
      if (sort !== 'default') filtered.sort((a,b) => sort === 'low' ? a.price-b.price : b.price-a.price);
      document.getElementById('result-count').textContent = `${filtered.length} product${filtered.length === 1 ? '' : 's'}`;
      document.getElementById('shop-grid').innerHTML = filtered.length ? filtered.map(card).join('') : '<p>No products found. Try another search.</p>';
    }
    ['category','search','sort'].forEach(id => document.getElementById(id).addEventListener('input',renderShop)); renderShop();
    if (window.BUNDLES.length) document.getElementById('bundles').innerHTML = window.BUNDLES.map(b => `<article class="panel"><h3>${escape(b.name)}</h3><p>${escape(b.description || '')}</p><button class="button gold" data-bundle="${escape(b.id)}">Add bundle to bag</button></article>`).join('');
    document.addEventListener('click', e => { const button = e.target.closest('[data-bundle]'); if (button) { const bundle = window.BUNDLES.find(b => String(b.id) === button.dataset.bundle); if (bundle) bundle.productIds.forEach(id => add(id)); } });
  }
  // Static crawlers see the generic product-page metadata; browsers get record-specific metadata.
  function metadata(title, description, url) {
    document.title = title;
    document.querySelector('meta[name="description"]').content = description;
    document.querySelector('meta[property="og:title"]').content = title;
    document.querySelector('meta[property="og:description"]').content = description;
    document.querySelector('meta[property="og:url"]').content = url;
    document.querySelector('link[rel="canonical"]').href = url;
  }
  // Product galleries use local assets and work when index.html is opened directly.
  function galleryMarkup(product) {
    const images = product.gallery || [{src:product.image, alt:product.alt, label:'Product'}];
    return `<div class="gallery"><a id="gallery-link" href="${images[0].src}" target="_blank" rel="noopener" aria-label="Open full-size product image"><img id="gallery-main" src="${images[0].src}" alt="${escape(images[0].alt)}"></a><p class="muted gallery-hint">Tap image to view full size.</p>${images.length>1 ? `<div class="gallery-thumbnails" aria-label="Product images">${images.map((im,index)=>`<button type="button" class="gallery-thumb" data-image="${index}" aria-label="View ${escape(im.label)} image" aria-pressed="${index===0}"><img src="${im.src}" alt="${escape(im.alt)}" loading="lazy"><span>${escape(im.label)}</span></button>`).join('')}</div>` : ''}</div>`;
  }
  if (page === 'product') {
    const product = find(new URLSearchParams(location.search).get('id'));
    const detail = document.getElementById('product-detail');
    if (!product) detail.innerHTML = '<div class="empty"><h1>Product not found.</h1><a class="button gold" href="shop.html">Explore the collection</a></div>';
    else {
      metadata(product.name + ' | Rawleaf', product.description + '. ' + product.pack + ' at ' + money(product.price) + '.', 'https://www.rawleafs.in/product.html?id=' + product.id);
      detail.innerHTML = `<p class="breadcrumbs"><a href="shop.html">Collection</a> / ${escape(product.shortName)}</p><div class="detail-grid">${galleryMarkup(product)}<div class="detail-info"><p class="eyebrow">${escape(product.category)} support</p><h1>${escape(product.name)}</h1><p class="lead">${escape(product.description)}.</p><p>${product.pack} per bottle</p><p class="detail-price">${money(product.price)}</p><p class="muted">Shipping charges confirmed before dispatch.</p><div class="detail-buy"><label>Quantity<input id="product-qty" type="number" min="1" max="99" value="1" inputmode="numeric"></label><button class="button gold" id="detail-add">Add to bag</button></div><div class="notice">Read the label and seek professional advice before use. Wellness support does not replace prescribed treatment.</div><div class="section"><details open><summary>Ingredients</summary><p>${escape(product.ingredients)}</p></details><details><summary>Directions for use</summary><p>${escape(product.directions)}</p></details><details><summary>Delivery and payment</summary><p>Choose COD or UPI at checkout. Our team confirms shipping and your order on WhatsApp.</p></details></div></div></div>`;
      document.querySelectorAll('[data-image]').forEach(button => button.addEventListener('click', () => {
        const selected = product.gallery[Number(button.dataset.image)];
        const main = document.getElementById('gallery-main'); main.src = selected.src; main.alt = selected.alt;
        document.getElementById('gallery-link').href = selected.src;
        document.querySelectorAll('[data-image]').forEach(b => b.setAttribute('aria-pressed', String(b === button)));
      }));
      document.getElementById('detail-add').addEventListener('click', () => { const qty = document.getElementById('product-qty'); if (qty.reportValidity()) add(product.id,Number(qty.value)); });
    }
  }
  if (page === 'concern') {
    const category = new URLSearchParams(location.search).get('category');
    const valid = categories.includes(category);
    const title = valid ? category + ' support' : 'Explore wellness concerns';
    metadata(title + ' | Rawleaf', 'Explore Rawleaf products for '+ (valid ? category.toLowerCase() : 'everyday wellness') + ' support.', 'https://www.rawleafs.in/concern.html' + (valid ? '?category='+encodeURIComponent(category) : ''));
    document.getElementById('concern-detail').innerHTML = `<p class="eyebrow">YOUR WELLNESS FOCUS</p><h1>${escape(title)}.</h1><p class="lead">Explore the collection and speak to a healthcare professional about what is suitable for you.</p><div class="product-grid">${products.filter(p => !valid || p.category === category).map(card).join('')}</div>`;
  }
  function totals() {
    const subtotal = cart.reduce((n,item) => n + find(item.id).price * item.qty,0);
    const reduction = discount ? Math.round(subtotal * discount.percent) / 100 : 0;
    return {subtotal,reduction,total:subtotal-reduction};
  }
  function renderCart() {
    const container = document.getElementById('cart-content');
    if (!cart.length) { container.innerHTML = '<div class="empty"><h2>Your bag is waiting.</h2><p>Discover support for your everyday routine.</p><a class="button gold" href="shop.html">Shop the collection</a></div>'; return; }
    const t = totals();
    container.innerHTML = `<div class="checkout-layout"><div><div id="cart-items">${cart.map(item => { const p=find(item.id); return `<article class="cart-item"><a href="product.html?id=${p.id}"><img src="${p.image}" alt="${escape(p.alt)}" width="800" height="800"></a><div><h3><a href="product.html?id=${p.id}">${escape(p.shortName)}</a></h3><p>${money(p.price)} · ${p.pack}</p><div class="cart-controls"><div class="quantity"><button data-qty="${p.id}" data-step="-1" aria-label="Decrease ${escape(p.shortName)} quantity">−</button><span aria-label="Quantity ${item.qty}">${item.qty}</span><button data-qty="${p.id}" data-step="1" aria-label="Increase ${escape(p.shortName)} quantity">+</button></div><strong>${money(p.price*item.qty)}</strong><button class="remove" data-remove="${p.id}">Remove</button></div></div></article>`; }).join('')}</div><div class="panel"><div class="summary-line"><span>Product subtotal</span><span>${money(t.subtotal)}</span></div><div class="summary-line"><span>Discount${discount?' ('+escape(discount.code)+')':''}</span><span>−${money(t.reduction)}</span></div><div class="summary-line total"><span>Product total</span><span>${money(t.total)}</span></div><p class="muted">Excludes shipping. Rawleaf will confirm any shipping charge before you confirm the order.</p><label>Have an offer code?<input id="discount-code" placeholder="Enter code" value="${discount?escape(discount.code):''}"></label><button type="button" class="button outline" id="apply-discount">Apply code</button><p id="discount-status" class="muted" role="status"></p></div></div><form id="checkout" class="panel"><h2>Delivery details.</h2><label>Full name<input name="name" required maxlength="80" autocomplete="name"></label><label>Mobile number<input name="phone" type="tel" required pattern="[6-9][0-9]{9}" maxlength="10" placeholder="10-digit Indian mobile number" autocomplete="tel-national" inputmode="tel"></label><label>Full delivery address<textarea name="address" required minlength="10" maxlength="600" rows="3" autocomplete="street-address" placeholder="House, street, area, city and state"></textarea></label><label>PIN code<input name="pincode" required pattern="[1-9][0-9]{5}" maxlength="6" inputmode="numeric" autocomplete="postal-code"></label><fieldset><legend>Payment method</legend><label class="radio-label"><input type="radio" name="payment" value="COD" checked>Cash on Delivery</label><label class="radio-label"><input type="radio" name="payment" value="UPI">UPI</label></fieldset><div class="upi-box" id="upi-section" hidden><h3>Pay with UPI</h3><p class="upi-id">${UPI}</p><button class="button outline" id="copy-upi" type="button">Copy UPI ID</button><div class="qr-placeholder" role="img" aria-label="UPI QR code placeholder, not a scannable payment code">UPI QR code<br>To be supplied<br>Use the UPI ID below</div><a class="button outline" href="upi://pay?pa=${encodeURIComponent(UPI)}&pn=Rawleaf&am=${t.total.toFixed(2)}&cu=INR">Open UPI app</a><p class="muted">Confirm the final payable amount with Rawleaf before paying. Payment receipt is verified manually.</p><label>Payment reference (if already paid)<input name="reference" maxlength="80" placeholder="UPI transaction reference"></label></div><p class="muted">Sending this opens WhatsApp with your order draft. Tap Send there; Rawleaf will confirm availability, shipping and payment. Your bag remains saved.</p><button type="submit" class="button gold checkout-submit">Send Order on WhatsApp</button></form></div>`;
    container.querySelectorAll('[data-qty]').forEach(button => button.addEventListener('click', () => { const item=cart.find(i=>i.id===Number(button.dataset.qty)); item.qty=Math.max(1,Math.min(99,item.qty+Number(button.dataset.step))); preserveAndRender(); }));
    container.querySelectorAll('[data-remove]').forEach(button => button.addEventListener('click', () => { cart=cart.filter(i=>i.id!==Number(button.dataset.remove)); preserveAndRender(); }));
    document.getElementById('apply-discount').addEventListener('click', () => { const code=document.getElementById('discount-code').value.trim().toUpperCase(); const offer=window.DISCOUNTS.find(d=>d.code.toUpperCase()===code && d.percent>0 && d.percent<=100); if (offer) { discount=offer; preserveAndRender(); notify('Offer applied.'); } else document.getElementById('discount-status').textContent='This code is not active. Contact Rawleaf for current offers.'; });
    document.querySelectorAll('[name=payment]').forEach(input => input.addEventListener('change', () => document.getElementById('upi-section').hidden = input.value !== 'UPI'));
    document.getElementById('copy-upi').addEventListener('click',async () => {
      try { await navigator.clipboard.writeText(UPI); notify('UPI ID copied.'); }
      catch { const textarea=document.createElement('textarea'); textarea.value=UPI;document.body.append(textarea);textarea.select();const copied=document.execCommand('copy');textarea.remove();notify(copied?'UPI ID copied.':'Select and copy the UPI ID shown above.'); }
    });
    document.getElementById('checkout').addEventListener('submit',event => {
      event.preventDefault(); if (!cart.length) return;
      const values=new FormData(event.target);const t=totals();
      const lines=['Hello Rawleaf, I would like to place an order.','',...cart.map(item=>`${find(item.id).name} × ${item.qty} — ${money(find(item.id).price*item.qty)}`),'',`Subtotal: ${money(t.subtotal)}`,`Discount: ${money(t.reduction)}${discount?' ('+discount.code+')':''}`,`Product total: ${money(t.total)}`, 'Shipping: please confirm',`Payment method: ${values.get('payment')}`,`Name: ${values.get('name').trim()}`,`Phone: ${values.get('phone')}`,`Address: ${values.get('address').trim()}`,`PIN code: ${values.get('pincode')}`];
      if (values.get('payment')==='UPI') lines.push(`UPI reference: ${values.get('reference').trim() || 'Not paid yet / pending verification'}`);
      lines.push('Please confirm availability, final payable amount and delivery details.');
      location.href=`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(lines.join('\n'))}`;
    });
  }
  // Keep delivery form values when the cart is changed.
  function preserveAndRender() {
    const form=document.getElementById('checkout'); const values=form?new FormData(form):null;
    save();renderCart();const newForm=document.getElementById('checkout');
    if(values&&newForm) { for(const [key,value] of values) { if(key==='payment') { const radio=newForm.querySelector(`input[name="payment"][value="${value}"]`);if(radio)radio.checked=true; } else if(newForm.elements[key])newForm.elements[key].value=value; } document.getElementById('upi-section').hidden=values.get('payment')!=='UPI'; }
  }
  if(page==='cart')renderCart();
  if(page==='contact')document.getElementById('enquiry').addEventListener('submit',event=>{event.preventDefault();const data=new FormData(event.target);location.href=`https://wa.me/${WHATSAPP}?text=${encodeURIComponent('Hello Rawleaf, my name is '+data.get('name').trim()+'.\n'+data.get('message').trim())}`;});
  window.addEventListener('storage',event=>{if(event.key===KEY){cart=readCart();updateCount();if(page==='cart')renderCart();}});
})();
